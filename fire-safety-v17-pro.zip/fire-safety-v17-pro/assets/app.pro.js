/* Fire Safety v17 Pro */
const SCHEMA = ["code","type","capacity","manufacturingDate","expiryDate","status","location","building","floor","zone","responsible","notes"];
const LS_KEY = "fs17pro:data";
const LS_HISTORY = "fs17pro:history";
const LS_ROLE = "fs17pro:role";
let supabase = null; let cfg = null;
const State = { items:[], history:{}, role:"viewer", user:null };

async function loadConfig(){
  try{
    const res = await fetch("./assets/config.json", {cache:"no-store"});
    if(!res.ok) throw new Error();
    cfg = await res.json();
  }catch{ cfg = null; }
}
function initSupabase(){
  if(!cfg) return;
  supabase = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
}
function saveLocal(){
  localStorage.setItem(LS_KEY, JSON.stringify(State.items));
  localStorage.setItem(LS_HISTORY, JSON.stringify(State.history));
  localStorage.setItem(LS_ROLE, State.role);
}
function loadLocal(){
  State.items = JSON.parse(localStorage.getItem(LS_KEY) || "[]");
  State.history = JSON.parse(localStorage.getItem(LS_HISTORY) || "{}");
  State.role = localStorage.getItem(LS_ROLE) || "viewer";
}
function qs(x){ return document.querySelector(x); }
function qsa(x){ return [...document.querySelectorAll(x)]; }
function fmtDate(s){ if(!s) return ""; const d=new Date(s); return isNaN(d)? s : d.toISOString().slice(0,10); }
function isExpired(it){ const t=new Date().toISOString().slice(0,10); return it.expiryDate && it.expiryDate<t; }

// Auth
async function signIn(){
  if(!supabase){ qs("#authStatus").textContent="(Local mode)"; return; }
  const email = qs("#authEmail").value.trim();
  const password = qs("#authPass").value.trim();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  qs("#authStatus").textContent = error? "เข้าสู่ระบบล้มเหลว: "+error.message : "เข้าสู่ระบบสำเร็จ";
  if(!error){ State.user = data.user; await loadRole(); await syncFromDB(); renderAll(); renderRole(); }
}
async function signUp(){
  if(!supabase){ qs("#authStatus").textContent="(Local mode)"; return; }
  const email = qs("#authEmail").value.trim();
  const password = qs("#authPass").value.trim();
  const { error } = await supabase.auth.signUp({ email, password });
  qs("#authStatus").textContent = error? "สมัครล้มเหลว: "+error.message : "สมัครสำเร็จ (ยืนยันอีเมล)";
}
async function signOut(){
  if(!supabase){ State.user=null; renderRole(); return; }
  await supabase.auth.signOut();
  State.user=null; renderRole();
}
async function loadRole(){
  State.role = "viewer";
  if(!supabase || !State.user) return;
  const { data } = await supabase.from("users_meta").select("role").eq("user_id", State.user.id).maybeSingle();
  State.role = data?.role || (cfg?.DEFAULT_ROLE || "viewer");
}
function can(perm){
  const map = {admin:["read","create","update","delete","import","export","assign_roles","settings"], inspector:["read","create","update","import","export"], viewer:["read","export"]};
  return (map[State.role]||[]).includes(perm);
}
function renderRole(){
  qs("#roleBox").textContent = State.user? `เข้าสู่ระบบ: ${State.user.email} · role: ${State.role}` : "ยังไม่เข้าสู่ระบบ (Local ใช้ได้)";
  saveLocal();
}

// DB Sync
async function syncFromDB(){
  if(!supabase || !State.user) return;
  const { data, error } = await supabase.from("extinguishers").select("*").order("code");
  if(error) return;
  State.items = (data||[]).map(r=>({code:r.code,type:r.type,capacity:r.capacity,manufacturingDate:r.manufacturing_date,expiryDate:r.expiry_date,status:r.status,location:r.location,building:r.building,floor:r.floor,zone:r.zone,responsible:r.responsible,notes:r.notes}));
  const { data:hist } = await supabase.from("inspections").select("*").order("inspected_at",{ascending:false}).limit(1000);
  State.history = {};
  (hist||[]).forEach(x=>{ (State.history[x.code]=State.history[x.code]||[]).push({ts:x.inspected_at,user:x.user_id,pressure:x.pressure,seal:x.seal,hose:x.hose,notes:x.notes}); });
  saveLocal();
}
async function upsertDB(items){
  if(!supabase || !State.user) return;
  const payload = items.map(it=>({code:it.code,type:it.type,capacity:it.capacity,manufacturing_date:it.manufacturingDate||null,expiry_date:it.expiryDate||null,status:it.status,location:it.location,building:it.building,floor:it.floor,zone:it.zone,responsible:it.responsible,notes:it.notes}));
  const { error } = await supabase.from("extinguishers").upsert(payload, { onConflict:"code" });
  if(error) alert("DB upsert error: "+error.message);
}
async function insertInspection(code, rec){
  if(!supabase || !State.user) return;
  const { error } = await supabase.from("inspections").insert({ code, pressure:rec.pressure, seal:rec.seal, hose:rec.hose, notes:rec.notes });
  if(error) alert("DB insert inspection error: "+error.message);
}

// Import CSV
function importCSVtoState(file){
  Papa.parse(file, { header:true, skipEmptyLines:true, complete: async res => {
    const cols = res.meta.fields || [];
    const missing = SCHEMA.filter(c=>!cols.includes(c));
    if(missing.length){ alert("คอลัมน์หาย: "+missing.join(", ")); return; }
    const cleaned = res.data.map(r => ({
      code:(r.code||"").trim(), type:(r.type||"").trim(), capacity:(r.capacity||"").trim(),
      manufacturingDate:fmtDate(r.manufacturingDate), expiryDate:fmtDate(r.expiryDate), status:(r.status||"").trim(),
      location:(r.location||"").trim(), building:(r.building||"").trim(), floor:(r.floor||"").trim(),
      zone:(r.zone||"").trim(), responsible:(r.responsible||"").trim(), notes:(r.notes||"").trim()
    }));
    const map = new Map(State.items.map(it=>[it.code,it]));
    cleaned.forEach(it=>{ if(!it.code) return; map.set(it.code, { ...map.get(it.code), ...it }); });
    State.items = [...map.values()];
    saveLocal(); renderAll();
    if(supabase && State.user && can("import")) await upsertDB(cleaned);
    alert("นำเข้าแล้ว: "+cleaned.length);
  }});
}

// UI
function renderStats(){
  const total=State.items.length, ok=State.items.filter(x=>x.status==="OK").length, maint=State.items.filter(x=>x.status==="MAINTENANCE").length, expired=State.items.filter(x=>x.status==="EXPIRED"||isExpired(x)).length;
  qs("#stat-total").textContent=total; qs("#stat-ok").textContent=ok; qs("#stat-maint").textContent=maint; qs("#stat-expired").textContent=expired;
}
let chartBuilding, chartStatus;
function renderCharts(){
  const byB={}, byS={};
  State.items.forEach(it=>{ byB[it.building]=(byB[it.building]||0)+1; const st=isExpired(it)?"EXPIRED":(it.status||"UNSET"); byS[st]=(byS[st]||0)+1; });
  const bK=Object.keys(byB).filter(Boolean), bV=bK.map(k=>byB[k]);
  const sK=Object.keys(byS).filter(Boolean), sV=sK.map(k=>byS[k]);
  if(chartBuilding) chartBuilding.destroy(); if(chartStatus) chartStatus.destroy();
  chartBuilding=new Chart(qs("#chartByBuilding"),{type:"bar",data:{labels:bK,datasets:[{label:"จำนวนถังตามอาคาร",data:bV}]},options:{responsive:true,maintainAspectRatio:false}});
  chartStatus=new Chart(qs("#chartByStatus"),{type:"doughnut",data:{labels:sK,datasets:[{label:"สถานะ",data:sV}]},options:{responsive:true,maintainAspectRatio:false}});
}
function ensureTabContent(){
  const inv=qs("#Inventory"); if(inv.innerHTML.trim()===""){ inv.innerHTML=`
    <div class="flex gap-2 mb-3">
      <input id="searchBox" class="border rounded-lg px-3 py-2" placeholder="ค้นหาทุกฟิลด์..."/>
      <button id="btnExportCSV" class="px-3 py-2 rounded-lg bg-slate-100">Export CSV</button>
    </div>
    <div class="overflow-auto">
      <table class="table text-sm"><thead class="bg-slate-50"><tr>${SCHEMA.map(h=>`<th>${h}</th>`).join("")}</tr></thead><tbody id="invBody"></tbody></table>
    </div>`; }
  const chk=qs("#Checklist"); if(chk.innerHTML.trim()===""){ chk.innerHTML=`
    <div class="grid md:grid-cols-2 gap-3">
      <div class="p-4 bg-white rounded-xl border">
        <h3 class="font-semibold">Quick Inspection</h3>
        <input id="chkCode" class="border rounded-lg px-3 py-2 w-full" placeholder="เช่น FX-001" />
        <div class="mt-2 grid grid-cols-3 gap-2 text-sm">
          <label class="flex items-center gap-2"><input type="checkbox" id="chkPressure" /> แรงดัน</label>
          <label class="flex items-center gap-2"><input type="checkbox" id="chkSeal" /> ซีล</label>
          <label class="flex items-center gap-2"><input type="checkbox" id="chkHose" /> สายฉีด</label>
        </div>
        <textarea id="chkNotes" class="mt-2 border rounded-lg w-full p-2" placeholder="บันทึก..."></textarea>
        <button id="btnSaveChk" class="mt-2 px-3 py-2 rounded-lg bg-emerald-600 text-white">บันทึกผล</button>
      </div>
      <div class="p-4 bg-white rounded-xl border">
        <h3 class="font-semibold">ประวัติ</h3>
        <div id="historyBox" class="text-sm"></div>
      </div>
    </div>`; }
  const qr=qs("#QR"); if(qr.innerHTML.trim()===""){ qr.innerHTML=`
    <div class="grid md:grid-cols-2 gap-3">
      <div class="p-4 bg-white rounded-xl border"><h3 class="font-semibold">📷 สแกน</h3><div id="qrReader" style="width:100%"></div></div>
      <div class="p-4 bg-white rounded-xl border"><h3 class="font-semibold">🏷️ สร้าง QR</h3><input id="qrCodeInput" class="border rounded-lg px-3 py-2 w-full" placeholder="กรอกรหัสถัง"/><canvas id="qrCanvas" class="mt-3 border rounded-lg bg-white"></canvas><button id="btnGenQR" class="mt-2 px-3 py-2 rounded-lg bg-emerald-600 text-white">Generate</button></div>
    </div>`; }
  const rep=qs("#Reports"); if(rep.innerHTML.trim()===""){ rep.innerHTML=`
    <button id="btnGenReport" class="px-3 py-2 rounded-lg bg-slate-800 text-white">Export JSON Report</button>
    <pre id="reportBox" class="mt-3 bg-slate-900 text-slate-100 p-3 rounded-lg overflow-auto text-xs"></pre>`; }
}
function renderInventoryTable(){
  const body=qs("#invBody"); if(!body) return;
  const q=(qs("#searchBox")?.value||"").toLowerCase().trim();
  const rows=State.items.filter(it=>!q||JSON.stringify(it).toLowerCase().includes(q));
  body.innerHTML = rows.map(it=>`<tr>${SCHEMA.map(k=>`<td>${it[k]||""}</td>`).join("")}</tr>`).join("");
}
function exportCSV(){
  const rows=[SCHEMA.join(",")]; State.items.forEach(it=>rows.push(SCHEMA.map(k=>(it[k]??"").toString().replace(/,/g," ")).join(",")));
  const blob=new Blob([rows.join("\n")],{type:"text/csv;charset=utf-8"}); const url=URL.createObjectURL(blob); const a=document.createElement("a"); a.href=url; a.download="fire-extinguishers-export.csv"; a.click(); URL.revokeObjectURL(url);
}
function renderHistory(code){
  const h=State.history[code]||[]; const box=qs("#historyBox"); if(!box) return;
  if(h.length===0){ box.textContent="ยังไม่มีประวัติ"; return; }
  box.innerHTML="<ul class='list-disc pl-5'>"+h.slice(-10).reverse().map(x=>`<li>${new Date(x.ts).toLocaleString()} · P:${x.pressure?"✓":"×"} S:${x.seal?"✓":"×"} H:${x.hose?"✓":"×"} · ${x.notes||""}</li>`).join("")+"</ul>";
}
async function saveChecklist(){
  const code=qs("#chkCode").value.trim();
  const rec={ts:Date.now(),pressure:qs("#chkPressure").checked,seal:qs("#chkSeal").checked,hose:qs("#chkHose").checked,notes:qs("#chkNotes").value.trim()};
  (State.history[code]=State.history[code]||[]).push({...rec,user:State.user?.email||"local"});
  if(supabase && State.user) await insertInspection(code, rec);
  renderHistory(code); saveLocal(); alert("บันทึกแล้ว");
}
function startQrScanner(){
  const el=document.getElementById("qrReader"); if(!el) return;
  try{ const qr=new Html5Qrcode("qrReader"); qr.start({facingMode:"environment"},{fps:10,qrbox:200},decoded=>{ alert("พบ: "+decoded); }); }catch(e){}
}
function genQR(){
  const code=(qs("#qrCodeInput")?.value||"").trim(); if(!code) return;
  const canvas=document.getElementById("qrCanvas"); window.QRCode.toCanvas(canvas, code, {errorCorrectionLevel:"M"});
}
function exportPDF(){
  const { jsPDF } = window.jspdf; const doc=new jsPDF({orientation:"landscape"});
  doc.setFontSize(14); doc.text((cfg?.ORG_NAME||"Organization")+" — Fire Extinguishers Summary",14,16);
  const rows=State.items.slice(0,500).map(it=>SCHEMA.map(k=>it[k]||""));
  doc.autoTable({ head:[SCHEMA], body:rows, startY:22, styles:{fontSize:8,cellPadding:1}, headStyles:{fillColor:[230,235,255]} });
  doc.save("fire-extinguishers-summary.pdf");
}
function switchTab(name){
  qsa(".tabview").forEach(el=>el.classList.add("hidden")); qs("#"+name).classList.remove("hidden");
  qsa("button.tab").forEach(b=>b.classList.toggle("active", b.getAttribute("data-tab")===name));
}
function initEvents(){
  qs("#btnSignIn").onclick=signIn; qs("#btnSignUp").onclick=signUp; qs("#btnSignOut").onclick=signOut;
  qs("#btnImport").onclick=()=>{ const f=qs("#csvFile").files?.[0]; if(!f) return alert("เลือกไฟล์ CSV"); if(!can("import")) return alert("สิทธิ์ไม่พอ"); importCSVtoState(f); };
  qs("#btnSync").onclick=()=>syncFromDB();
  qs("#btnExportPDF").onclick=exportPDF;
  qs("#btnGenReport")?.addEventListener("click",()=>{ const r={generatedAt:new Date().toISOString(),total:State.items.length,byStatus:State.items.reduce((a,x)=>{const k=isExpired(x)?"EXPIRED":(x.status||"UNSET"); a[k]=(a[k]||0)+1; return a;},{}),}; qs("#reportBox").textContent=JSON.stringify(r,null,2); });
  qs("#btnExportCSV")?.addEventListener("click",exportCSV);
  qs("#searchBox")?.addEventListener("input",renderInventoryTable);
  qs("#btnSaveChk")?.addEventListener("click",saveChecklist);
  qsa("button.tab").forEach(btn=>btn.onclick=()=>switchTab(btn.getAttribute("data-tab")));
  const mobile=qs("#mobileTabs"); if(mobile){ mobile.onchange=()=>switchTab(mobile.value); }
  startQrScanner();
}
async function upsertDB(items){
  const payload=items.map(it=>({code:it.code,type:it.type,capacity:it.capacity,manufacturing_date:it.manufacturingDate||null,expiry_date:it.expiryDate||null,status:it.status,location:it.location,building:it.building,floor:it.floor,zone:it.zone,responsible:it.responsible,notes:it.notes}));
  const { error } = await supabase.from("extinguishers").upsert(payload,{onConflict:"code"});
  if(error) alert("DB upsert error: "+error.message);
}
async function insertInspection(code, rec){
  const { error } = await supabase.from("inspections").insert({code,pressure:rec.pressure,seal:rec.seal,hose:rec.hose,notes:rec.notes});
  if(error) alert("DB insert inspection error: "+error.message);
}
function renderAll(){ ensureTabContent(); renderStats(); renderCharts(); renderInventoryTable(); renderRole(); }
(async function(){
  loadLocal(); await loadConfig(); initSupabase(); initEvents();
  if(supabase){ const { data:{user} } = await supabase.auth.getUser(); State.user=user||null; if(State.user){ await loadRole(); await syncFromDB(); } }
  renderAll();
})();