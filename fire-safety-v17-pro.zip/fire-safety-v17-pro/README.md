# Fire Safety Checklist System v17 **Pro** — Auth + DB + PDF (Local-first fallback)

- 🔐 Supabase Auth (Email/Password)
- 🧩 RBAC (admin / inspector / viewer)
- 🗄️ Supabase Postgres (extinguishers, inspections)
- 📑 Export PDF (jsPDF + autoTable)
- 💾 Local-first fallback (ยังใช้งานได้แม้ไม่ตั้งค่า DB)

## โครงสร้าง
```
fire-safety-v17-pro/
├─ index.html
├─ assets/
│  ├─ app.pro.js
│  ├─ style.css
│  ├─ rbac.json
│  └─ config.example.json   ← คัดลอกเป็น config.json แล้วใส่ค่า
└─ sql/
   └─ schema.sql
```

## ตั้งค่า Supabase
1) สร้างโปรเจกต์ → SQL Editor → วาง `sql/schema.sql` → Run  
2) Authentication: เปิด Signups (ถ้าต้องการ)  
3) คัดลอก Project URL + anon public key  
4) คัดลอก `assets/config.example.json` → `assets/config.json` และใส่ค่าจริง  
5) Deploy ขึ้น Netlify (HTTPS ช่วยให้ QR ใช้กล้องได้)

## ใช้งาน
- Sign in → กด **Sync DB** เพื่อโหลดข้อมูล
- นำเข้า CSV แล้วระบบจะ upsert ตาม `code` (ต้องมีสิทธิ์ `inspector`/`admin`)
- Export PDF ได้จากปุ่ม **Export PDF**

> หมายเหตุ: หากต้องการหลายองค์กร ให้เพิ่ม `org_id` ในทุกตารางและปรับ RLS
