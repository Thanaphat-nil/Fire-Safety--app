
create table if not exists public.extinguishers (
  code text primary key,
  type text,
  capacity text,
  manufacturing_date date,
  expiry_date date,
  status text,
  location text,
  building text,
  floor text,
  zone text,
  responsible text,
  notes text,
  owner uuid references auth.users(id) default auth.uid(),
  inserted_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

create table if not exists public.inspections (
  id bigserial primary key,
  code text references public.extinguishers(code) on delete cascade,
  inspected_at timestamp with time zone default now(),
  pressure boolean,
  seal boolean,
  hose boolean,
  notes text,
  user_id uuid references auth.users(id) default auth.uid()
);

create table if not exists public.users_meta (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'viewer',
  display_name text
);

alter table public.extinguishers enable row level security;
alter table public.inspections enable row level security;
alter table public.users_meta enable row level security;

create policy "read extinguishers" on public.extinguishers
for select using ( auth.role() = 'authenticated' );

create policy "insert extinguishers" on public.extinguishers
for insert with check ( auth.uid() = owner );

create policy "update extinguishers" on public.extinguishers
for update using ( auth.uid() = owner ) with check ( auth.uid() = owner );

create policy "delete extinguishers" on public.extinguishers
for delete using ( auth.uid() = owner );

create policy "read inspections" on public.inspections
for select using ( auth.role() = 'authenticated' );

create policy "write inspections" on public.inspections
for insert with check ( auth.role() = 'authenticated' )
    using ( auth.role() = 'authenticated' );

create policy "read users_meta" on public.users_meta
for select using ( auth.uid() = user_id );

create policy "write own users_meta" on public.users_meta
for insert with check ( auth.uid() = user_id )
    using ( auth.uid() = user_id );

create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end; $$ language plpgsql;

drop trigger if exists set_updated_at on public.extinguishers;
create trigger set_updated_at before update on public.extinguishers
for each row execute function public.set_updated_at();
